/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const flux_analyze: (a: number, b: number, c: number) => void;
export const flux_compress: (a: number, b: number, c: number) => void;
export const flux_decompress: (a: number, b: number, c: number) => void;
export const flux_session_compress: (a: number, b: number, c: number, d: number) => void;
export const flux_session_create: () => number;
export const flux_session_create_with_config: (a: number, b: number, c: number, d: number) => number;
export const flux_session_decompress: (a: number, b: number, c: number, d: number) => void;
export const flux_session_destroy: (a: number) => number;
export const flux_session_reset: (a: number, b: number) => void;
export const flux_session_stats: (a: number, b: number) => void;
export const flux_stream_create: () => number;
export const flux_stream_destroy: (a: number) => number;
export const flux_stream_receive: (a: number, b: number, c: number, d: number) => void;
export const flux_stream_reset: (a: number, b: number) => void;
export const flux_stream_stats: (a: number, b: number) => void;
export const flux_stream_update: (a: number, b: number, c: number, d: number) => void;
export const flux_version: (a: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_export: (a: number, b: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number) => void;
