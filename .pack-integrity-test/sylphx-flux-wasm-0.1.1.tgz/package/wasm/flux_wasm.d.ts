/* tslint:disable */
/* eslint-disable */

/**
 * Analyze data and estimate compression potential
 * Returns JSON with entropy statistics
 */
export function flux_analyze(data: Uint8Array): string;

/**
 * Compress JSON data using FLUX
 *
 * Best for one-off compression. For repeated compression of similar data,
 * use session-based compression instead.
 */
export function flux_compress(data: Uint8Array): Uint8Array;

/**
 * Decompress FLUX data
 */
export function flux_decompress(data: Uint8Array): Uint8Array;

/**
 * Compress using FLUX session (enables schema caching)
 */
export function flux_session_compress(session_id: number, data: Uint8Array): Uint8Array;

/**
 * Create a new FLUX session for schema-cached compression
 * Returns session ID
 */
export function flux_session_create(): number;

/**
 * Create a FLUX session with custom configuration
 */
export function flux_session_create_with_config(columnar: boolean, entropy: boolean, delta: boolean, checksum: boolean): number;

/**
 * Decompress using FLUX session
 */
export function flux_session_decompress(session_id: number, data: Uint8Array): Uint8Array;

/**
 * Destroy a FLUX session
 */
export function flux_session_destroy(session_id: number): boolean;

/**
 * Reset FLUX session state
 */
export function flux_session_reset(session_id: number): void;

/**
 * Get FLUX session statistics as JSON
 */
export function flux_session_stats(session_id: number): string;

/**
 * Create a new streaming session for delta compression
 * Ideal for WebSocket-style real-time state updates
 */
export function flux_stream_create(): number;

/**
 * Destroy a streaming session
 */
export function flux_stream_destroy(session_id: number): boolean;

/**
 * Receive delta and reconstruct full state
 */
export function flux_stream_receive(session_id: number, data: Uint8Array): Uint8Array;

/**
 * Reset streaming session state
 */
export function flux_stream_reset(session_id: number): void;

/**
 * Get streaming session statistics
 */
export function flux_stream_stats(session_id: number): string;

/**
 * Send state update, returns compressed delta
 * First call returns full state, subsequent calls return only changes
 */
export function flux_stream_update(session_id: number, json: Uint8Array): Uint8Array;

/**
 * Get library version
 */
export function flux_version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly flux_analyze: (a: number, b: number, c: number) => void;
    readonly flux_compress: (a: number, b: number, c: number) => void;
    readonly flux_decompress: (a: number, b: number, c: number) => void;
    readonly flux_session_compress: (a: number, b: number, c: number, d: number) => void;
    readonly flux_session_create: () => number;
    readonly flux_session_create_with_config: (a: number, b: number, c: number, d: number) => number;
    readonly flux_session_decompress: (a: number, b: number, c: number, d: number) => void;
    readonly flux_session_destroy: (a: number) => number;
    readonly flux_session_reset: (a: number, b: number) => void;
    readonly flux_session_stats: (a: number, b: number) => void;
    readonly flux_stream_create: () => number;
    readonly flux_stream_destroy: (a: number) => number;
    readonly flux_stream_receive: (a: number, b: number, c: number, d: number) => void;
    readonly flux_stream_reset: (a: number, b: number) => void;
    readonly flux_stream_stats: (a: number, b: number) => void;
    readonly flux_stream_update: (a: number, b: number, c: number, d: number) => void;
    readonly flux_version: (a: number) => void;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_export: (a: number, b: number) => number;
    readonly __wbindgen_export2: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
